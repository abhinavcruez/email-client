import { useEffect, useState } from 'react';
import Login from './components/Login';
import EmailDetail from './components/EmailDetail';
import AppLayout from './components/AppLayout';
import { MantineProvider } from '@mantine/core';
import { Notifications } from '@mantine/notifications';



export interface User {
  uid: string;
  email: string;
}

const App = () => {
  const token = localStorage.getItem('token');
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    if (!token) {
      setUser(null);
    }
  }, [token]);

  const handleBack = () => {
    //    setSelectedEmail(null);
  };

  return (
    <MantineProvider>
      <Notifications />
      {!token ? (
        <Login onLogin={setUser} />
      ) : (
        <AppLayout>
          <EmailDetail email={null} onBack={handleBack} />
        </AppLayout>
      )}
    </MantineProvider>
  );
};

export default App;
