import { create } from 'zustand';

interface Email {
    uid: string;
    subject: string;
    sender: string;
    date: string;
    body: string;
}

interface EmailStore {
    selectedEmail: Email | null;
    setSelectedEmail: (email: Email) => void;
}

const useEmailStore = create<EmailStore>((set) => ({
    selectedEmail: null,
    setSelectedEmail: (email: Email) => set({ selectedEmail: email }),
}));

export default useEmailStore;
