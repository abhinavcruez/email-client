import React from 'react';
import useEmailStore from '../store/useEmailStore';

const EmailDetails: React.FC = () => {
    const selectedEmail = useEmailStore((state) => state.selectedEmail);

    if (!selectedEmail) {
        return (
            <div className="flex items-center justify-center h-64 bg-gray-50 rounded-lg">
                <p className="text-gray-500 text-sm">Select an email to view its contents</p>
            </div>
        );
    }

    return (
        <div className="">
            <div className="space-y-6">
                {/* Header Section */}
                <div className="border-b border-gray-200 pb-4">
                    <h1 className="text-2xl font-semibold text-gray-900 mb-2">
                        {selectedEmail.subject}
                    </h1>

                    <div className="flex items-center text-sm text-gray-600">
                        <div className="flex items-center gap-3">
                            {/* Sender Avatar */}
                            <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                                <span className="text-blue-700 font-semibold">
                                    {selectedEmail.sender.charAt(0).toUpperCase()}
                                </span>
                            </div>
                            <span className="font-medium">{selectedEmail.sender}</span>
                        </div>
                        <span className="mx-2 text-gray-400">•</span>
                        <time className="text-gray-500">
                            {new Date(selectedEmail.date).toLocaleString()}
                        </time>
                    </div>
                </div>

                {/* Email Body */}
                <div className="prose max-w-none text-gray-700 leading-relaxed">
                    <div className="whitespace-pre-wrap">
                        {selectedEmail.body}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default EmailDetails;
