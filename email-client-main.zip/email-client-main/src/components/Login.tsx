import { useState } from 'react';
import { TextInput, PasswordInput, Button, Title, Alert, Paper } from '@mantine/core';
import axiosInstance from '../config/axiosInstance';
import classes from './AuthenticationImage.module.css';
import { notifications } from '@mantine/notifications';

interface LoginProps {
    onLogin: (user: any) => void;
}

const Login: React.FC<LoginProps> = ({ onLogin }) => {
    const [email, setEmail] = useState<string>('');
    const [password, setPassword] = useState<string>('');
    const [error, setError] = useState<string>('');
    const [loading, setLoading] = useState<boolean>(false);

    const handleLogin = async () => {
        try {
            setLoading(true);
            const response = await axiosInstance.post('/login/', { email, password });
            onLogin(response.data.user);
            localStorage.setItem('token', response.data.token);
            localStorage.setItem('user', JSON.stringify(response.data.user));
            setLoading(false);
            notifications.show({
                title: 'Login successful',
                message: 'You have successfully logged in',
                color: 'teal',
            });
        } catch (err) {
            setError((err as Error).message);
            setLoading(false);
        }
    };

    return (
        <div className={classes.wrapper}>
            <Paper className={classes.form} radius={0} p={30}>
                <Title order={2} className={classes.title} ta="center" mt="md" mb={50}>
                    Welcome!
                </Title>

                <TextInput value={email} onChange={(e) => setEmail(e.target.value)} label="Email address" placeholder="hello@gmail.com" size="md" />
                <PasswordInput value={password} onChange={(e) => setPassword(e.target.value)} label="Password" placeholder="Your password" mt="md" size="md" />
                {error && <Alert color="red">{error}</Alert>}
                <Button onClick={handleLogin} fullWidth mt="xl" size="md" loading={loading} >
                    Login
                </Button>
            </Paper>
        </div>
    );
};

export default Login;
