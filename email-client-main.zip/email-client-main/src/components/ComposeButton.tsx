import { Group, Button, Dialog } from '@mantine/core';
import { useDisclosure } from '@mantine/hooks';
import ComposeEmail from './ComposeEmail';

function ComposeButton() {
    const [composeOpened, { toggle: composeToggle, close: composeClose }] = useDisclosure(false);

    return (
        <>
            <Group justify="center">
                <Button onClick={composeToggle}>Compose Email</Button>
            </Group>
            <Dialog opened={composeOpened} withCloseButton onClose={composeClose} size="lg" radius="md">
                <ComposeEmail />
            </Dialog>
        </>
    );
}

export default ComposeButton;
