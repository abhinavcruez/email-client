import React, { useEffect, useState } from 'react';
import { AppShell, Text, Burger, Flex, Group, Button, Affix } from '@mantine/core';
import { useDisclosure } from '@mantine/hooks';
import EmailList from './EmailList';
import ComposeButton from './ComposeButton';
import { User } from '../App';

interface AppLayoutProps {
    children: React.ReactNode;
}

const AppLayout: React.FC<AppLayoutProps> = ({ children }) => {
    const [opened, { toggle }] = useDisclosure();
    const [user, setUser] = useState<User | null>(null);

    useEffect(() => {
        const user = JSON.parse(localStorage.getItem('user') ?? '{}');
        setUser(user);
    }, []);

    return (
        <AppShell
            header={{ height: { base: 60, md: 70, lg: 80 } }}
            navbar={{
                width: { base: 200, md: 300, lg: 400 },
                breakpoint: 'sm',
                collapsed: { mobile: !opened },
            }}
            padding="md"
        >
            <AppShell.Header>
                <Group h="100%" px="md">
                    <Burger opened={opened} onClick={toggle} hiddenFrom="sm" size="sm" />
                    <Text size="xl">{user?.email}</Text>
                    <Button variant="light" onClick={() => {
                        localStorage.removeItem('token')
                        window.location.reload();
                    }}> Logout </Button>
                </Group>
            </AppShell.Header>

            <AppShell.Navbar p="md">
                <Flex mih={50} gap="md" justify="center" align="center" direction="column" wrap="wrap">
                    <EmailList folder='inbox' />
                </Flex>
            </AppShell.Navbar>

            <AppShell.Main>
                {children}
                <Affix position={{ bottom: 20, right: 20 }}>
                    <ComposeButton />
                </Affix>
            </AppShell.Main>
        </AppShell>
    );
};

export default AppLayout;
