import React, { useEffect, useState } from 'react';
import { List, Container, Text, Box, LoadingOverlay, Alert, Paper, ScrollArea } from '@mantine/core';
import axiosInstance from '../config/axiosInstance';
import { useDisclosure } from '@mantine/hooks';
import useEmailStore from '../store/useEmailStore';

interface Email {
    uid: string;
    subject: string;
    sender: string;
    date: string;
    body: string;
}

interface EmailListProps {
    folder: string;
}

const EmailList: React.FC<EmailListProps> = ({ folder }) => {
    const [emails, setEmails] = useState<Email[]>([]);
    const [loading, { open, close }] = useDisclosure(true);
    const [error, setError] = useState<string | null>(null);
    const setSelectedEmail = useEmailStore((state) => state.setSelectedEmail);

    useEffect(() => {
        fetchEmails();
    }, [folder]);

    const fetchEmails = async () => {
        try {
            open();
            const response = await axiosInstance.get(`/emails/?folder=${folder}`);
            const emailData = response.data.emails.emails || [];
            setEmails(emailData);
            close();
        } catch (error) {
            setError((error as Error).message);
            close();
        }
    };

    if (loading) {
        return (
            <div className="max-w-4xl mx-auto p-6">
                <div className="animate-pulse space-y-4">
                    {[...Array(5)].map((_, i) => (
                        <div key={i} className="bg-gray-200 rounded-lg p-4">
                            <div className="h-4 bg-gray-300 rounded w-3/4 mb-2"></div>
                            <div className="h-3 bg-gray-300 rounded w-1/2"></div>
                        </div>
                    ))}
                </div>
            </div>
        );
    }
    return (
        <div className="max-w-4xl mx-auto p-6">
            <h2 className="text-2xl font-semibold text-gray-800 mb-6">{folder}</h2>

            <div className="relative">
                {error ? (
                    <div className="bg-red-50 border-l-4 border-red-500 p-4 mb-4">
                        <div className="flex">
                            <div className="flex-shrink-0">
                                <svg className="h-5 w-5 text-red-400" viewBox="0 0 20 20" fill="currentColor">
                                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                                </svg>
                            </div>
                            <div className="ml-3">
                                <p className="text-sm text-red-700">{error}</p>
                            </div>
                        </div>
                    </div>
                ) : (
                    <div className="h-[32rem] overflow-y-auto pr-2">
                        {emails.length > 0 ? (
                            <div className="space-y-4">
                                {emails.map((email) => (
                                    <div
                                        onClick={() => setSelectedEmail(email)}
                                        key={email.uid}
                                        className="bg-white rounded-lg shadow-sm hover:shadow-md transition-all duration-200 p-4 cursor-pointer border border-gray-100 hover:border-gray-200 group"
                                    >
                                        <h3 className="text-lg font-semibold text-gray-800 group-hover:text-blue-600 transition-colors duration-200">
                                            {email.subject}
                                        </h3>
                                        <div className="flex items-center text-sm text-gray-500 mt-1 mb-2">
                                            <span className="font-medium">{email.sender}</span>
                                            <span className="mx-2">•</span>
                                            <span>{new Date(email.date).toLocaleString()}</span>
                                        </div>
                                        <p className="text-gray-600 text-sm line-clamp-2">
                                            {email.body}
                                        </p>
                                    </div>
                                ))}
                            </div>
                        ) : (
                            <div className="text-center py-12">
                                <svg className="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                                </svg>
                                <p className="mt-2 text-sm text-gray-500">No emails found in this folder</p>
                            </div>
                        )}
                    </div>
                )}
            </div>
        </div>
    );
};

export default EmailList;