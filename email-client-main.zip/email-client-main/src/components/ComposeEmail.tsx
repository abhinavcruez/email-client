import { useState } from 'react';
import { TextInput, Textarea, Button, Container } from '@mantine/core';
import axiosInstance from '../config/axiosInstance';
import { notifications } from '@mantine/notifications';

const ComposeEmail: React.FC = () => {
    const [to, setTo] = useState<string>('');
    const [subject, setSubject] = useState<string>('');
    const [body, setBody] = useState<string>('');

    const handleSend = async () => {
        try {
            await axiosInstance.post('/emails/', { to, subject, body });
            setTo('');
            setSubject('');
            setBody('');
            notifications.show({
                title: 'Email sent',
                message: 'Your email has been sent successfully',
                color: 'teal',
            })
        } catch (err) {
            notifications.show({
                title: 'Error',
                message: (err as Error).message,
                color: 'red',
            })
        }
    };

    return (
        <Container>
            <TextInput label="To" value={to} onChange={(e) => setTo(e.target.value)} />
            <TextInput label="Subject" value={subject} onChange={(e) => setSubject(e.target.value)} />
            <Textarea label="Body" value={body} onChange={(e) => setBody(e.target.value)} />
            <Button onClick={handleSend}>Send</Button>
        </Container>
    );
};

export default ComposeEmail;
